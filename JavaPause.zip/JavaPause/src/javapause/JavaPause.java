/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javapause;


import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import javax.swing.JFrame;
import javax.swing.Timer;

public class JavaPause extends JFrame implements WindowFocusListener, ActionListener  {    

    public static double scale = 0.5;
   
    public JavaPause() {
        initUI();
    }
    
    private void initUI(){
        add(new MyPanel());
        myTimer();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        double width = screenSize.getWidth();
        double height = screenSize.getHeight();
        Dimension size = new Dimension((int)(width*scale), (int)(height*scale));
        setSize(size);
        setUndecorated(true);
        addWindowFocusListener(this);
        setAlwaysOnTop(true);
        setFocusable(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
    }
    
    private void myTimer() {
        Timer timer = new Timer(100, this);
        timer.setInitialDelay(1900);
        timer.start(); 
    }
    
    @Override
    public void windowGainedFocus(WindowEvent e){}
    
    @Override
    public void windowLostFocus(WindowEvent e)
    {
            setAlwaysOnTop(false);
            setAlwaysOnTop(true);
            System.out.println("focus lost");
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
            setAlwaysOnTop(false);
            setAlwaysOnTop(true);
            System.out.println("Timit");        
    }
    
      public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            JavaPause jp = new JavaPause();
            jp.setVisible(true);
        });        

    }

}
