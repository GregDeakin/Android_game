/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javapause;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.event.ActionListener;


/**
 *
 * @author deakig
 */

public class MyPanel extends JPanel implements ActionListener{
    
    public MyPanel(){
        initMyPanel();
    }

    
    private void initMyPanel(){
        setFocusable(true);
        myTimer();
        addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent e) {

                //System.out.println("Key pressed code=" + e.getKeyCode() + ", char=" + e.getKeyChar());
                if(e.getKeyCode() == KeyEvent.VK_SPACE){
                }

            }

            @Override
            public void keyReleased(KeyEvent e) { 
             //   System.out.println("Key released code=" + e.getKeyCode() + ", char=" + e.getKeyChar());
            }

            @Override
            public void keyTyped(KeyEvent e) {
            }
        });        
        
    }

    private void myTimer() {
        Timer timer = new Timer(100, this);
        timer.setInitialDelay(10000);
        timer.start(); 
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.dispose();
      //  Toolkit.getDefaultToolkit().sync();
    }    

    @Override
    public void actionPerformed(ActionEvent e) {
        
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

    
    
}
